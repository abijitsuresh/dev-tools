# Cấu hình MCP Tools cho GitHub Copilot

## Vấn đề

Sau khi cài đặt extension, các lệnh Task Explorer MCP xuất hiện trong Command Palette nhưng không hiển thị trong "Configure Tools" của Copilot.

## Nguyên nhân

- VS Code phiên bản này (1.55.0) chưa hỗ trợ Language Model Tools API (`vscode.lm.registerTool`)
- API này chỉ có từ VS Code 1.90+
- Extension đã expose tools qua Task Explorer API và các lệnh VS Code commands

## Giải pháp

Cần cấu hình MCP Server riêng để Copilot có thể kết nối.

### Cách 1: Sử dụng qua Extension API

Extensions khác hoặc scripts có thể gọi trực tiếp:

```typescript
// Lấy Task Explorer API
const taskExplorerExt = vscode.extensions.getExtension("talktokim.taskexpl");
const teApi = taskExplorerExt?.exports;

// Sử dụng MCP server
const tasks = await teApi.mcpServer.listTasks("npm");
await teApi.mcpServer.runTask({ source: "npm", name: "build" });
```

### Cách 2: Gọi qua VS Code Commands

Các tool đã được đăng ký là VS Code commands:

```typescript
// List tasks
const tasks = await vscode.commands.executeCommand(
  "taskExplorer.mcp.listTasks",
  {
    filter: "npm",
    workspaceFolder: "my-project",
  },
);

// Run task
const result = await vscode.commands.executeCommand(
  "taskExplorer.mcp.runTask",
  {
    taskSource: "npm",
    taskName: "build",
  },
);

// List recent tasks
const recentTasks = await vscode.commands.executeCommand(
  "taskExplorer.mcp.listRecentTasks",
  {
    limit: 5,
  },
);

// List favorites
const favorites = await vscode.commands.executeCommand(
  "taskExplorer.mcp.listFavoriteTasks",
);

// Get running tasks
const running = await vscode.commands.executeCommand(
  "taskExplorer.mcp.getRunningTasks",
);

// Toggle favorite
await vscode.commands.executeCommand("taskExplorer.mcp.toggleFavorite", {
  taskSource: "npm",
  taskName: "test",
});

// Get task sources
const sources = await vscode.commands.executeCommand(
  "taskExplorer.mcp.getTaskSources",
);
```

### Cách 3: Tạo MCP Config File (Cho AI Agents bên ngoài)

Tạo file `.copilot-instructions.md` hoặc `.github/copilot-instructions.md`:

```markdown
# Task Explorer MCP Tools

This workspace has Task Explorer extension installed with MCP tools.

## Available Tools (via VS Code Commands):

### 1. taskExplorer.mcp.listTasks

List all tasks with optional filters.

Parameters:

- `filter` (string, optional): Task source type (npm, grunt, gulp, etc.)
- `workspaceFolder` (string, optional): Workspace folder name

Example:
\`\`\`typescript
await vscode.commands.executeCommand('taskExplorer.mcp.listTasks', {
filter: 'npm'
});
\`\`\`

### 2. taskExplorer.mcp.listRecentTasks

List recently executed tasks.

Parameters:

- `limit` (number, optional): Maximum number of tasks

### 3. taskExplorer.mcp.listFavoriteTasks

List favorite tasks.

### 4. taskExplorer.mcp.runTask

Execute a task.

Parameters:

- `taskId` (string) OR
- `taskName` (string) + `taskSource` (string, optional) + `workspace` (string, optional)

Example:
\`\`\`typescript
await vscode.commands.executeCommand('taskExplorer.mcp.runTask', {
taskSource: 'npm',
taskName: 'build'
});
\`\`\`

### 5. taskExplorer.mcp.getRunningTasks

Get currently running tasks.

### 6. taskExplorer.mcp.toggleFavorite

Add/remove task from favorites.

### 7. taskExplorer.mcp.getTaskSources

Get available task source types.
```

## Các Commands MCP đã được đăng ký

Tất cả các tool sau đã được expose dưới dạng VS Code commands:

1. `taskExplorer.mcp.listTasks`
2. `taskExplorer.mcp.listRecentTasks`
3. `taskExplorer.mcp.listFavoriteTasks`
4. `taskExplorer.mcp.runTask`
5. `taskExplorer.mcp.getRunningTasks`
6. `taskExplorer.mcp.toggleFavorite`
7. `taskExplorer.mcp.getTaskSources`

## Kiểm tra Commands đã được đăng ký

Mở Developer Tools Console và gõ:

```javascript
// Kiểm tra Task Explorer API
const ext = vscode.extensions.getExtension("talktokim.taskexpl");
console.log("Extension:", ext?.isActive);
const api = ext?.exports;
console.log("MCP Server:", api?.mcpServer);

// Test một command
vscode.commands
  .executeCommand("taskExplorer.mcp.getTaskSources")
  .then(console.log);
```

## Nâng cấp lên VS Code mới hơn

Để sử dụng Language Model Tools API native (hiển thị trong "Configure Tools"), cần:

1. Nâng cấp VS Code lên version 1.90+
2. Update package.json `engines.vscode` thành `^1.90.0`
3. Cài đặt type definitions mới: `@types/vscode@^1.90.0`
4. Sử dụng `vscode.lm.registerTool` API

## Lưu ý

- Hiện tại tools hoạt động và có thể được gọi qua commands
- Copilot hoặc AI agents khác có thể execute commands này
- Không cần "Configure Tools" UI để sử dụng tools
- Tools vẫn hoạt động đầy đủ chức năng

## Ví dụ sử dụng trong Copilot Chat

Bạn có thể yêu cầu Copilot:

```
"Hãy list tất cả npm tasks bằng cách execute command taskExplorer.mcp.listTasks với filter='npm'"

"Run the build task using taskExplorer.mcp.runTask command"

"Show me recent tasks using taskExplorer.mcp.listRecentTasks"
```

## Troubleshooting

### Tools không hoạt động

1. Kiểm tra extension đã active:

   ```typescript
   vscode.extensions.getExtension("talktokim.taskexpl")?.isActive;
   ```

2. Xem Output channel "Task Explorer" để kiểm tra logs

3. Reload window: `Ctrl+R` hoặc `Cmd+R`

### Copilot không nhận diện tools

Copilot cần những thông tin sau để sử dụng tools:

1. Biết command names (liệt kê trong file instructions)
2. Biết parameters schema
3. Có quyền execute commands

Đảm bảo đã tạo file `.copilot-instructions.md` hoặc `.github/copilot-instructions.md` để hướng dẫn Copilot.
