# Task Explorer MCP Integration

This extension now includes built-in MCP (Model Context Protocol) server functionality that allows AI agents to interact with VS Code tasks programmatically.

## Available MCP Tools

The Task Explorer MCP server provides 7 tools for AI agents:

1. **taskexplorer_list_tasks** - List all available tasks with optional filters
2. **taskexplorer_list_recent_tasks** - List recently executed tasks
3. **taskexplorer_list_favorite_tasks** - List user's favorite tasks
4. **taskexplorer_run_task** - Execute a specific task
5. **taskexplorer_get_running_tasks** - Get currently executing tasks
6. **taskexplorer_toggle_favorite** - Add/remove tasks from favorites
7. **taskexplorer_get_task_sources** - Get available task source types

## Quick Start

### Using MCP Commands (UI)

You can access MCP functionality through the Command Palette:

1. `Task Explorer MCP: List All Tasks` - Browse and view all tasks
2. `Task Explorer MCP: List Recent Tasks` - View and run recent tasks
3. `Task Explorer MCP: List Favorite Tasks` - Manage and run favorite tasks
4. `Task Explorer MCP: Get Task Sources` - See available task types

### Using MCP API (Programmatic)

Other extensions can access the MCP server:

```typescript
// Get Task Explorer API
const taskExplorerExt = vscode.extensions.getExtension("talktokim.taskexpl");
const teApi = taskExplorerExt?.exports;

// Access MCP server
const mcpServer = teApi?.mcpServer;

// List all npm tasks
const npmTasks = await mcpServer.listTasks("npm");

// Run a task
await mcpServer.runTask({
  source: "npm",
  name: "build",
  workspace: "my-project",
});

// Get recent tasks
const recentTasks = await mcpServer.listRecentTasks(5);

// Get favorites
const favorites = await mcpServer.listFavoriteTasks();

// Toggle favorite
await mcpServer.toggleFavorite({
  source: "npm",
  name: "test",
});
```

### Using MCP Protocol (External Clients)

The MCP protocol handler can process standard MCP requests:

```typescript
const response = await teApi.mcpProtocol.handleRequest({
  method: "tools/call",
  params: {
    name: "taskexplorer_list_tasks",
    arguments: {
      filter: "npm",
      workspaceFolder: "my-project",
    },
  },
});
```

## Features for AI Agents

AI agents using this MCP server can:

- **Discover** all available tasks in the workspace
- **Filter** tasks by type (npm, grunt, gulp, etc.) or workspace
- **Execute** build, test, deployment, or custom tasks
- **Monitor** currently running tasks
- **Manage** task favorites for quick access
- **Review** task execution history

## Supported Task Types

The MCP server works with all task types supported by Task Explorer:

- npm / yarn
- Workspace (VS Code tasks)
- ant
- gradle
- grunt
- gulp
- make
- maven
- composer (PHP)
- bash/shell scripts
- batch scripts
- python
- perl
- powershell
- ruby
- pipenv
- nsis
- And more through external providers

## Example Use Cases

### For AI Coding Assistants

```
User: "Run the build task"
AI: Uses taskexplorer_list_tasks to find build tasks
    Uses taskexplorer_run_task to execute it
    Returns: "Build task started successfully"

User: "What tasks did I run recently?"
AI: Uses taskexplorer_list_recent_tasks
    Returns: List of recent tasks with details

User: "Add the test task to my favorites"
AI: Uses taskexplorer_toggle_favorite
    Returns: "Task added to favorites"
```

### For Automation Tools

```typescript
// Build automation workflow
const mcpServer = teApi.mcpServer;

// 1. Check if build task exists
const tasks = await mcpServer.listTasks("npm");
const hasBuild = tasks.some((t) => t.name === "build");

// 2. Run build if it exists
if (hasBuild) {
  await mcpServer.runTask({ source: "npm", name: "build" });
}

// 3. Monitor running status
const running = await mcpServer.getRunningTasks();
console.log(`${running.length} tasks currently running`);
```

## API Reference

### listTasks(filter?, workspaceFolder?)

List all available tasks with optional filters.

**Parameters:**

- `filter` (string, optional): Task source type (e.g., 'npm', 'grunt')
- `workspaceFolder` (string, optional): Workspace folder name

**Returns:** Array of task objects

### listRecentTasks(limit?)

List recently executed tasks.

**Parameters:**

- `limit` (number, optional): Maximum number of tasks to return

**Returns:** Array of recent task objects

### listFavoriteTasks()

List user's favorite tasks.

**Returns:** Array of favorite task objects

### runTask(identifier)

Execute a specific task.

**Parameters:**

- `identifier`: Task ID (string) or object with:
  - `source` (string): Task source type
  - `name` (string): Task name
  - `workspace` (string, optional): Workspace folder

**Returns:** Object with execution result

### getRunningTasks()

Get currently executing tasks.

**Returns:** Array of running task objects

### toggleFavorite(identifier)

Add or remove task from favorites.

**Parameters:**

- `identifier`: Task ID (string) or object with source, name, workspace

**Returns:** Object with action result ('added' or 'removed')

### getTaskSources()

Get available task source types.

**Returns:** Array of source type strings

## Configuration

The MCP server is automatically initialized when Task Explorer extension activates. No additional configuration needed.

## Detailed Documentation

See [src/mcp/README.md](src/mcp/README.md) for detailed MCP protocol documentation and examples.

## License

Same as Task Explorer extension.
