# The New Task Explorer

Discover, organize, and execute tasks from 20+ sources in a single tree view — now with AI integration via Language Model Tools for GitHub Copilot.

[![codecov](https://codecov.io/gh/talktokim/taskexpl/branch/master/graph/badge.svg)](https://codecov.io/gh/talktokim/taskexpl)
[![GitHub issues](https://img.shields.io/github/issues-raw/talktokim/taskexpl.svg?logo=github)](https://github.com/talktokim/taskexpl/issues)
[![GitHub last commit](https://img.shields.io/github/last-commit/talktokim/taskexpl.svg?logo=github)](https://github.com/talktokim/taskexpl)

![npm](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/npm.png?raw=true) ![ant](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/ant.png?raw=true) ![yarn](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/yarn.png?raw=true) ![grunt](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/grunt.png?raw=true) ![gulp](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/gulp.png?raw=true) ![gradle](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/gradle.png?raw=true) ![workspace](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/workspace.png?raw=true) ![make](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/make.png?raw=true) ![tsc](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/ts.png?raw=true) ![batch](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/bat.png?raw=true) ![ruby](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/ruby.png?raw=true) ![powershell](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/powershell.png?raw=true) ![bash](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/bash.png?raw=true) ![python](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/python.png?raw=true) ![nsis](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/nsis.png?raw=true) ![maven](https://github.com/talktokim/taskexpl/raw/HEAD/res/sources/maven.png?raw=true)

## Description

**The New Task Explorer** provides a tree view in the Explorer panel and/or Sidebar that displays all supported tasks organized by workspace folder, task source file, and task name. Tasks can be opened for editing, executed, stopped, restarted, and managed through favorites and recent task lists. Multi-root workspaces are fully supported.

This extension is a community-driven continuation and improvement based on the original **vscode-taskexplorer** created by **Scott Meesseman** (spmeesseman). The original extension was incredibly powerful and beloved by many developers for years, offering an excellent visual interface for managing and running tasks from npm, shell scripts, grunt, gulp, and many other providers.

However, in recent times, the original extension has encountered persistent issues for a number of users, including frequent hangs, freezes, or even crashes during VS Code startup — especially in larger or multi-root workspaces. Many in the community have attributed these problems (at least in part) to changes related to the introduction of a licensing/trial system, which added overhead or checks that sometimes interfered with smooth activation and scanning.

We fully empathize with the challenges and personal difficulties the original author, **Scott Meesseman**, has faced. Maintaining a popular open-source project over many years is no easy task, and decisions like shifting to a paid model often stem from real-life pressures, responsibilities, or personal circumstances.

We are truly grateful to **Scott** for building such an outstanding extension in the first place. It brought immense value to the VS Code community, inspired countless workflows, and laid the foundation for better task management inside the editor. Many forks and alternatives (including this one) exist today precisely because of the strong base he created.

Thank you, **Scott**, for your dedication and for the wonderful tool you shared with all of us. Your work continues to live on through these community efforts, helping developers everywhere stay productive. If you're maintaining or using **The New Task Explorer**, we hope it brings back the smooth, reliable experience many missed! 😊

## Table of Contents

- [The New Task Explorer](#the-new-task-explorer)
  - [Description](#description)
  - [Table of Contents](#table-of-contents)
  - [Requirements](#requirements)
  - [Supported Task Types](#supported-task-types)
  - [Screenshots](#screenshots)
  - [Features](#features)
  - [AI Integration (Language Model Tools)](#ai-integration-language-model-tools)
    - [Available Tools](#available-tools)
    - [Usage with Copilot](#usage-with-copilot)
    - [MCP Commands (Command Palette)](#mcp-commands-command-palette)
  - [Configuration](#configuration)
    - [Task Type Enable/Disable](#task-type-enabledisable)
    - [View Settings](#view-settings)
    - [Grouping Settings](#grouping-settings)
    - [File Discovery](#file-discovery)
    - [Custom Executable Paths](#custom-executable-paths)
    - [Debug Settings](#debug-settings)
  - [Configuring Global Excludes, Apache Ant and Bash Globs](#configuring-global-excludes-apache-ant-and-bash-globs)
  - [Ant and Gulp Self-Provided Tasks](#ant-and-gulp-self-provided-tasks)
  - [Using Groups with a Separator](#using-groups-with-a-separator)
  - [Internally Provided Tasks vs. VS Code Provided Tasks](#internally-provided-tasks-vs-vs-code-provided-tasks)
  - [Running Bash/Shell Scripts in Windows](#running-bashshell-scripts-in-windows)
  - [Parsing Reports](#parsing-reports)
  - [External Provider Integration API](#external-provider-integration-api)
    - [Getting the API](#getting-the-api)
    - [Registering a Provider](#registering-a-provider)
    - [Unregistering](#unregistering)
    - [API Types](#api-types)
    - [TaskExplorerApi Interface](#taskexplorerapi-interface)
  - [MCP Server (Programmatic API)](#mcp-server-programmatic-api)
    - [MCP Protocol (Standard Request/Response)](#mcp-protocol-standard-requestresponse)
  - [Development](#development)
    - [Build](#build)
    - [Test](#test)
    - [Project Structure](#project-structure)
  - [Feedback \& Contributing](#feedback--contributing)
  - [License](#license)

## Requirements

- **Visual Studio Code v1.96.0** or higher
- Node.js runtime (bundled with VS Code)

## Supported Task Types

| Category        | Types                                                                                                |
| --------------- | ---------------------------------------------------------------------------------------------------- |
| **Build Tools** | npm, yarn, Ant, Gradle, Grunt, Gulp, Make, Maven                                                     |
| **Languages**   | Composer (PHP), Pipenv (Python), App-Publisher                                                       |
| **Scripts**     | Bash (.sh), Batch (.bat, .cmd), PowerShell (.ps1), Python (.py), Ruby (.rb), Perl (.pl), NSIS (.nsi) |
| **VS Code**     | Workspace tasks (tasks.json), TypeScript (tsc)                                                       |
| **External**    | Any third-party provider via the [External Provider API](#external-provider-integration-api)         |

Each task type can be individually enabled or disabled in settings.

## Screenshots

| Explorer Tray                             | Sidebar View                              | Task Type Groups                          |
| ----------------------------------------- | ----------------------------------------- | ----------------------------------------- |
| ![ss0](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/taskview1.png?raw=true) | ![ss1](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/taskview2.png?raw=true) | ![ss2](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/taskview3.png?raw=true) |

| Grunt/Gulp in Subfolders                  | Npm Commands                              | Task Groupings                            |
| ----------------------------------------- | ----------------------------------------- | ----------------------------------------- |
| ![ss4](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/taskview4.png?raw=true) | ![ss5](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/taskview5.png?raw=true) | ![ss6](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/taskview6.png?raw=true) |

| Multi-Level Groupings                     | Run with Args / No Terminal               | Last Tasks & Favorites                    |
| ----------------------------------------- | ----------------------------------------- | ----------------------------------------- |
| ![ss7](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/taskview7.png?raw=true) | ![ss8](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/taskview8.png?raw=true) | ![ss9](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/taskview9.png?raw=true) |

## Features

- **Tree view** in Explorer and/or Sidebar — organize tasks by folder, file, and group
- **20+ task providers** — npm, Ant, Gradle, Grunt, Gulp, Make, Maven, Composer, Pipenv, scripts, and more
- **Favorites** — mark frequently used tasks for quick access
- **Last Tasks** — automatically tracks recently executed tasks (configurable up to 20)
- **Task grouping** — group tasks by separator character (e.g., `dev-build`, `prod-build` → grouped by `dev` / `prod`)
- **Multi-level grouping** — nested groups up to 5 levels deep
- **Multi-root workspace** support
- **Run with arguments** — pass custom arguments to any task
- **Run without terminal** — execute tasks in background
- **Context menu actions** — run, stop, restart, pause, open terminal, open source file, add to excludes, rename
- **NPM management** — install, update, audit, audit fix via context menu on package.json nodes
- **Custom executable paths** — configure paths for ant, gradle, make, maven, bash, python, and more
- **Running task indicators** — animated icons and status bar message for active tasks
- **Parsing reports** — view detailed reports of discovered tasks
- **File system watching** — auto-refresh tree when task files change
- **External provider API** — third-party extensions can register custom task types
- **AI integration** — 7 Language Model Tools for GitHub Copilot

## AI Integration (Language Model Tools)

Task Explorer registers **7 Language Model Tools** with VS Code, making all task management features available to **GitHub Copilot** and other AI agents directly from the chat panel.

### Available Tools

| Tool                               | Reference Name       | Description                                                                      |
| ---------------------------------- | -------------------- | -------------------------------------------------------------------------------- |
| `taskexplorer_list_tasks`          | `#listTasks`         | List all available tasks, optionally filtered by source type or workspace folder |
| `taskexplorer_list_recent_tasks`   | `#listRecentTasks`   | List recently executed tasks                                                     |
| `taskexplorer_list_favorite_tasks` | `#listFavoriteTasks` | List tasks marked as favorites                                                   |
| `taskexplorer_run_task`            | `#runTask`           | Execute a task by ID, name, or source+name                                       |
| `taskexplorer_get_running_tasks`   | `#runningTasks`      | Get currently executing tasks                                                    |
| `taskexplorer_toggle_favorite`     | `#toggleFavorite`    | Add or remove a task from favorites                                              |
| `taskexplorer_get_task_sources`    | `#taskSources`       | Get available task source types                                                  |

### Usage with Copilot

These tools appear in **Copilot Chat > Configure Tools** and can be referenced in prompts:

```
"List all npm tasks in this workspace"
"Run the build task"
"What tasks did I run recently?"
"Add the test task to favorites"
```

### MCP Commands (Command Palette)

Four MCP commands are also available from the Command Palette (`Ctrl+Shift+P`):

- `Task Explorer MCP: List All Tasks`
- `Task Explorer MCP: List Recent Tasks`
- `Task Explorer MCP: List Favorite Tasks`
- `Task Explorer MCP: Get Task Sources`

## Configuration

All settings are under the `taskExplorer.*` namespace.

### Task Type Enable/Disable

```jsonc
"taskExplorer.enabledTasks": {
    "npm": true,        // npm scripts
    "ant": true,        // Apache Ant
    "gradle": true,     // Gradle
    "grunt": true,      // Grunt
    "gulp": true,       // Gulp
    "make": true,       // Makefile
    "maven": true,      // Maven
    "composer": true,   // PHP Composer
    "pipenv": true,     // Python Pipenv
    "bash": true,       // Bash scripts
    "batch": true,      // Batch scripts
    "powershell": true, // PowerShell scripts
    "python": true,     // Python scripts
    "ruby": true,       // Ruby scripts
    "perl": true,       // Perl scripts
    "tsc": true,        // TypeScript
    "workspace": true,  // VS Code tasks.json
    "nsis": false,      // NSIS (off by default)
    "appPublisher": false
}
```

### View Settings

| Setting                           | Type                    | Default  | Description                            |
| --------------------------------- | ----------------------- | -------- | -------------------------------------- |
| `enableExplorerView`              | boolean                 | `true`   | Show task tree in Explorer panel       |
| `enableSideBar`                   | boolean                 | `false`  | Show task tree in Sidebar              |
| `clickAction`                     | `"Open"` \| `"Execute"` | `"Open"` | Default action when clicking a task    |
| `showLastTasks`                   | boolean                 | `true`   | Show "Last Tasks" folder               |
| `numLastTasks`                    | number                  | `10`     | Number of recent tasks to track (1–20) |
| `showRunningTask`                 | boolean                 | `true`   | Show running task in status bar        |
| `showFavoritesButton`             | boolean                 | `true`   | Show favorites toggle button           |
| `showExecuteWithArgumentsButton`  | boolean                 | `false`  | Show "Run with Arguments" button       |
| `showExecuteWithNoTerminalButton` | boolean                 | `false`  | Show "Run without Terminal" button     |
| `disableAnimatedIcons`            | boolean                 | `false`  | Disable animated running task icons    |

### Grouping Settings

| Setting               | Type    | Default | Description                       |
| --------------------- | ------- | ------- | --------------------------------- |
| `groupWithSeparator`  | boolean | `true`  | Enable task grouping by separator |
| `groupSeparator`      | string  | `"-"`   | Separator character for grouping  |
| `groupMaxLevel`       | number  | `1`     | Max grouping depth (1–5)          |
| `groupStripTaskLabel` | boolean | `true`  | Strip group prefix from task name |

### File Discovery

| Setting            | Type     | Default       | Description                             |
| ------------------ | -------- | ------------- | --------------------------------------- |
| `exclude`          | string[] | _(see below)_ | Glob patterns to exclude from scanning  |
| `excludeTask`      | string[] | `[]`          | Regex patterns to exclude tasks by name |
| `includeAnt`       | string[] | `[]`          | Additional Ant file glob patterns       |
| `globPatternsAnt`  | string[] | `[]`          | Custom Ant file patterns                |
| `globPatternsBash` | string[] | `[]`          | Custom Bash file patterns               |
| `autoRefresh`      | boolean  | `true`        | Auto-refresh on file changes            |

Default exclusions include `**/.vscode-test/**`, `**/bin/**`, `**/build/**`, `**/dist/**`, `**/out/**`, `**/node_modules/**`, and more.

### Custom Executable Paths

```jsonc
"taskExplorer.pathToPrograms": {
    "ant": "ant.bat",
    "bash": "bash",
    "composer": "composer",
    "gradle": "gradle.bat",
    "make": "nmake",
    "maven": "mvn",
    "nsis": "makensis",
    "perl": "perl",
    "pipenv": "pipenv",
    "powershell": "powershell",
    "python": "python",
    "ruby": "ruby"
}
```

### Debug Settings

| Setting      | Type    | Default | Description             |
| ------------ | ------- | ------- | ----------------------- |
| `debug`      | boolean | `false` | Enable verbose logging  |
| `debugLevel` | number  | `1`     | Logging verbosity (1–5) |

## Configuring Global Excludes, Apache Ant and Bash Globs

The setting _exclude_ defines a file/directory pattern or an array of file/directory patterns to ignore using _Glob Patterns_ or a valid _File URI_. The setting applies to all script types. For example:

- `taskExplorer.exclude: [ "**/.vscode-test/**", "**/vendor/**", "**/out/**", "**/output/**", "/c:/projects/project1/src/theme/test/package.json" ]`

Note that the glob pattern "\*\*/node*modules/\*\*" is applied by default to the excludes list in all cases. Using the \_exclude* configuration can greatly improve performance in large workspaces if configured correctly.

Task files that are found by Task Explorer can also be added to the _excludes_ list via the tree node context menu, by right clicking the task file or task group node, and selecting _Add to Excludes_.

**Apache Ant** uses an .xml file extension, the setting _globPatternsAnt_ can be used to specify other file names other than [Bb]uild.xml to include as ant files so that all xml files do not need to be searched (slowing down tree refreshes in large workspaces or project with a large number of various xml files). The setting defines a file pattern or an array of file patterns to include using _Glob Patterns_ or a valid _File URI_, for example:

- `taskExplorer.globPatternsAnt: [ "**/extraTasks.xml", "**/scripts/ant/*.xml", "/c:/projects/project1/scripts/test/antetests.xml" ]`

Note that the glob pattern "\*\*/[Bb]uild.xml" is applied by default to the **Ant** includes list in all cases. If you don't include the asterisked glob pattern `**/` first in the string, files in sub-folders will not be found.

In the same way as for **Ant** tasks, **Bash** scripts without extensions can be configured to be found by the Bash Task Provider by using glob patterns in the same way, with the _globPatternsBash_ setting:

- `taskExplorer.globPatternsBash: [ "**/bash_scripts/**", "**/sh/scripts/**", "/usr/local/bin/start_task" ]`

## Ant and Gulp Self-Provided Tasks

By default, a custom parser is used to locate Ant and Gulp tasks in respective files. This may be fine in most cases, but in cases where the script and/or build files become complex, or there is something in the file that was not coded into the parser, you can use the _ant_ and _gulp_ programs themselves to find their own tasks. Note however that turning this on has a negative performance impact when refreshing and providing tasks to the VSCode Task Host.

## Using Groups with a Separator

**EXPERIMENTAL**
The _Groups With Separator_ option is simply an extra level of task groupings that can be made based on a configured separation character in the script name. This option can be turned on/off with the _Group With Seperator_ option in Settings, the default is OFF. The default separator is a dash ("-").

For example, consider 10 npm tasks, 5 of which all start with the string _dev-_, 5 of which start with the string _prod-_. Prior to Version 1.23, this would create 10 individual task nodes within the main npm task node in the task tree:

    npm
        dev-build
        dev-build-server
        dev-build-themes
        dev-cp-from-bin
        dev-clean
        prod-build
        prod-build-server
        prod-build-themes
        prod-cp-from-bin
        prod-clean

By enabling the _Group With Separator_ option in Settings and setting the _Group Separator_ to a dash ("-") two new grouped nodes would be created underneath the main npm node, one called _dev_ and the other called _prod_. Each of these two sub-nodes of course would contain the respective _dev-_ and _prod-_ scripts/tasks, minus the prepended group name:

    npm
        dev
            build
            build-server
            build-themes
            cp-from-bin
            clean
        prod
            build
            build-server
            build-themes
            cp-from-bin
            clean

## Internally Provided Tasks vs. VS Code Provided Tasks

The following tasks are provided by VSCode:

- Workspace (.vscode/tasks.json)
- NPM (\*\*/package.json)

All other tasks are internally provided. Workspace tasks are detected by VSCode in all cases. However, NPM tasks are detected only if the setting `'Npm -> Auto Detect'` is turned on in VSCode Settings. By default this is turned on, but if NPM tasks are not displaying, please check this setting, also check the setting that turns npm package management off in favor of Yarn `'Npm -> Package manager'`. A future release will contain internally provided NPM and Yarn tasks. Note these tasks are still displayed in the Task Tree, just not "provided" by this extension.

Detection of all internally provided task types can be turned on/off in Settings - `'Task Explorer -> Enable [Tasktype]'`.

## Running Bash/Shell Scripts in Windows

Bash/sh scripts in Windows will have the shell executable automatically set to a bash shell. The shell executable can be configured via `taskExplorer.pathToPrograms.bash`. If not set, and Git Bash exists at the default installation path, Git Bash (MinGW) will be used. Otherwise, `bash.exe` is assumed to be on the system PATH.

## Parsing Reports

For debugging or curiosity, a report can be generated listing all parsed components and the properties found. You can generate a report in the explorer context menus using the `Task Explorer: View Parsing Report` menu item.

![parsing-report-img](https://github.com/talktokim/taskexpl/raw/HEAD/res/readme/parsingreport.png)

## External Provider Integration API

Third-party extensions can register custom task types with Task Explorer.

### Getting the API

```typescript
const taskExplorerExt = vscode.extensions.getExtension("talktokim.taskexpl");
const teApi = taskExplorerExt?.exports as TaskExplorerApi;
```

### Registering a Provider

```typescript
await teApi.register("myTaskType", myProvider);
```

### Unregistering

```typescript
await teApi.unregister("myTaskType");
```

### API Types

Install type definitions:

```bash
npm install @talktokim/taskexpl-types
```

### TaskExplorerApi Interface

```typescript
interface TaskExplorerApi {
  log: any;
  utilities: any;
  fileCache: any;
  explorer?: TaskTreeDataProvider;
  sidebar?: TaskTreeDataProvider;
  providers: Map<string, TaskExplorerProvider>;
  providersExternal: Map<string, ExternalExplorerProvider>;
  mcpServer?: TaskExplorerMcpServer;
  mcpProtocol?: McpProtocolHandler;

  isBusy(): boolean;
  refresh(taskSource: string): Promise<void>;
  register(
    taskSource: string,
    provider: ExternalExplorerProvider,
  ): Promise<void>;
  unregister(taskSource: string): Promise<void>;
}
```

> **Note:** Always check `teApi.isBusy()` before calling API methods to ensure the indexer is not running.

## MCP Server (Programmatic API)

The built-in MCP server allows programmatic access to task management features. Other extensions and external clients can interact with tasks via the MCP protocol.

```typescript
const teApi = vscode.extensions.getExtension("talktokim.taskexpl")?.exports;

// List all npm tasks
const npmTasks = await teApi.mcpServer.listTasks("npm");

// Run a task
await teApi.mcpServer.runTask({ source: "npm", name: "build" });

// Get recent tasks
const recentTasks = await teApi.mcpServer.listRecentTasks(5);

// Get favorites
const favorites = await teApi.mcpServer.listFavoriteTasks();

// Toggle favorite
await teApi.mcpServer.toggleFavorite({ source: "npm", name: "test" });

// Get running tasks
const running = await teApi.mcpServer.getRunningTasks();

// Get task sources
const sources = await teApi.mcpServer.getTaskSources();
```

### MCP Protocol (Standard Request/Response)

```typescript
const response = await teApi.mcpProtocol.handleRequest({
  method: "tools/call",
  params: {
    name: "taskexplorer_list_tasks",
    arguments: { filter: "npm", workspaceFolder: "my-project" },
  },
});
```

For detailed MCP documentation, see [MCP_INTEGRATION.md](https://github.com/talktokim/taskexpl/blob/HEAD/MCP_INTEGRATION.md).

## Development

### Build

```bash
npm run build              # TypeScript compile
npm run webpack-build      # Webpack production bundle
npm run watch              # TypeScript watch mode
npm run webpack-watch      # Webpack watch mode
```

### Test

```bash
npm run test-all           # All tests
npm run test-providers     # Provider tests only
npm run test-tree          # Tree tests only
npm run test-npm           # NPM tests only
npm run test-ant           # Ant tests only
npm run test-gulp          # Gulp tests only
npm run test-api           # API tests only
```

Tests use **Mocha** with **NYC** for code coverage.

### Project Structure

```
src/
  extension.ts          - Entry point, activate() function
  cache.ts              - File caching, glob scanning, FileSystemWatcher
  providers/            - Task providers (ant, gradle, grunt, gulp, make, maven, etc.)
  tree/                 - TreeDataProvider (tree.ts, item.ts, file.ts, folder.ts)
  commands/             - VS Code command handlers
  mcp/                  - MCP server + Language Model Tools integration
  common/               - Configuration, logging, utilities
  interface/            - TypeScript interfaces and API definitions
  lib/                  - Helper functions
  test/                 - Test suites
test-files/             - Test fixture files
types/                  - Published npm types package
```

## Feedback & Contributing

- Report bugs and suggestions via [Issues](https://github.com/talktokim/taskexpl/issues)
- Submit [Pull Requests](https://github.com/talktokim/taskexpl/pulls)

## License

See [LICENSE](https://github.com/talktokim/taskexpl/blob/HEAD/LICENSE) for details.
