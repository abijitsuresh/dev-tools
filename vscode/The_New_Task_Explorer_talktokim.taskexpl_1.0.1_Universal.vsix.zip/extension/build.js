require("esbuild")
  .build({
    entryPoints: ["./src/extension.ts"],
    bundle: true,
    platform: "node",
    target: "node16",
    outfile: "dist/extension.js",
    external: ["vscode"],
  })
  .catch(() => process.exit(1));
