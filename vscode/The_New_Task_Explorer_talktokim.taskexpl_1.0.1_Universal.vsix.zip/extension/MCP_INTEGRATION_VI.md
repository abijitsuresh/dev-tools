# Tích hợp MCP Server cho Task Explorer

## Tổng quan

Đã bổ sung thành công tính năng MCP (Model Context Protocol) server cho Task Explorer extension, cho phép các AI agent tương tác với các task trong VS Code.

## Các tính năng đã được thêm vào

### 1. MCP Server Core (`src/mcp/server.ts`)

Cung cấp 7 công cụ MCP cho AI agents:

1. **taskexplorer_list_tasks** - Liệt kê tất cả tasks với bộ lọc tùy chọn
2. **taskexplorer_list_recent_tasks** - Liệt kê các task vừa chạy
3. **taskexplorer_list_favorite_tasks** - Liệt kê các task yêu thích
4. **taskexplorer_run_task** - Chạy một task cụ thể
5. **taskexplorer_get_running_tasks** - Lấy danh sách task đang chạy
6. **taskexplorer_toggle_favorite** - Thêm/xóa task khỏi danh sách yêu thích
7. **taskexplorer_get_task_sources** - Lấy danh sách các loại task (npm, grunt, gulp, etc.)

### 2. MCP Protocol Handler (`src/mcp/protocol.ts`)

Xử lý các yêu cầu MCP theo chuẩn Model Context Protocol, bao gồm:

- Khởi tạo kết nối
- Liệt kê các công cụ có sẵn
- Xử lý lời gọi công cụ
- Trả về kết quả theo định dạng MCP

### 3. Lệnh UI (`src/commands/mcpCommands.ts`)

4 lệnh mới trong Command Palette:

- `Task Explorer MCP: List All Tasks` - Xem và liệt kê tất cả tasks
- `Task Explorer MCP: List Recent Tasks` - Xem và chạy các task gần đây
- `Task Explorer MCP: List Favorite Tasks` - Quản lý và chạy task yêu thích
- `Task Explorer MCP: Get Task Sources` - Xem các loại task có sẵn

### 4. Tích hợp API

MCP server được expose qua Task Explorer API:

```typescript
const teApi = vscode.extensions.getExtension("talktokim.taskexpl")?.exports;
const mcpServer = teApi?.mcpServer;
const mcpProtocol = teApi?.mcpProtocol;
```

## Cách sử dụng

### Dành cho người dùng (UI)

1. Mở Command Palette (`Ctrl+Shift+P` hoặc `Cmd+Shift+P`)
2. Gõ "Task Explorer MCP" để xem các lệnh có sẵn
3. Chọn lệnh phù hợp để tương tác với tasks

### Dành cho Extension Developers

```typescript
// Lấy API
const taskExplorerExt = vscode.extensions.getExtension("talktokim.taskexpl");
const teApi = taskExplorerExt?.exports;
const mcpServer = teApi?.mcpServer;

// Liệt kê các task npm
const npmTasks = await mcpServer.listTasks("npm");

// Chạy task build
await mcpServer.runTask({
  source: "npm",
  name: "build",
});

// Lấy task gần đây
const recentTasks = await mcpServer.listRecentTasks(5);
```

### Dành cho AI Agents

AI agents có thể sử dụng MCP protocol để:

- Khám phá các task trong workspace
- Lọc task theo loại hoặc workspace
- Thực thi build, test, deploy tasks
- Theo dõi task đang chạy
- Quản lý task yêu thích
- Xem lịch sử chạy task

## Các loại task được hỗ trợ

- npm / yarn
- Workspace (VS Code tasks)
- ant, gradle, grunt, gulp
- make, maven
- composer (PHP)
- bash/shell, batch scripts
- python, perl, powershell, ruby
- pipenv, nsis
- Và nhiều loại khác qua external providers

## Cấu trúc file mới

```
src/
  mcp/
    index.ts          - Export module
    server.ts         - MCP server implementation
    protocol.ts       - MCP protocol handler
    README.md         - Tài liệu chi tiết
  commands/
    mcpCommands.ts    - UI commands for MCP
```

## Tài liệu

- [MCP_INTEGRATION.md](../MCP_INTEGRATION.md) - Tài liệu đầy đủ (tiếng Anh)
- [src/mcp/README.md](src/mcp/README.md) - Chi tiết về MCP protocol và các công cụ

## Ví dụ sử dụng

### Ví dụ 1: Liệt kê và chạy task

```typescript
const tasks = await mcpServer.listTasks("npm");
console.log(`Found ${tasks.length} npm tasks`);

// Chạy task đầu tiên
if (tasks.length > 0) {
  await mcpServer.runTask(tasks[0].id);
}
```

### Ví dụ 2: Quản lý favorites

```typescript
// Thêm vào favorites
await mcpServer.toggleFavorite({
  source: "npm",
  name: "test",
});

// Lấy danh sách favorites
const favorites = await mcpServer.listFavoriteTasks();
console.log("Favorite tasks:", favorites);
```

### Ví dụ 3: Theo dõi task đang chạy

```typescript
// Chạy task
await mcpServer.runTask({ source: "npm", name: "build" });

// Kiểm tra task đang chạy
const running = await mcpServer.getRunningTasks();
console.log(`${running.length} tasks are running`);
```

## Lưu ý kỹ thuật

- MCP server tự động khởi tạo khi extension active
- Task được tự động thêm vào "Recent Tasks" khi chạy qua MCP
- Danh sách "Recent Tasks" giới hạn 10 tasks
- Favorites được lưu trữ persistent qua các phiên làm việc
- Task ID là tổ hợp duy nhất của source, name và workspace

## Kiểm thử

Để kiểm thử tính năng:

1. **Build extension:**

   ```bash
   npm run build
   ```

2. **Chạy extension trong Debug mode:**
   - Nhấn F5 trong VS Code
   - Extension sẽ khởi động trong Extension Development Host

3. **Kiểm tra MCP commands:**
   - Mở Command Palette
   - Gõ "Task Explorer MCP"
   - Thử các lệnh khác nhau

4. **Kiểm tra API:**
   ```typescript
   // Trong Developer Console
   const ext = vscode.extensions.getExtension("talktokim.taskexpl");
   const api = ext?.exports;
   console.log("MCP Server:", api?.mcpServer);
   ```

## Troubleshooting

### Nếu MCP Server không khởi tạo

- Kiểm tra Output channel "Task Explorer" để xem logs
- Đảm bảo extension được activate thành công
- Xem Developer Tools console để kiểm tra lỗi

### Nếu không thấy commands

- Reload window (`Ctrl+R` hoặc `Cmd+R`)
- Kiểm tra package.json đã được update đúng
- Xác nhận rằng commands đã được đăng ký trong extension.ts

## Tương lai

Có thể mở rộng thêm:

- Thêm resources MCP (không chỉ tools)
- Hỗ trợ prompts MCP
- Streaming kết quả cho long-running tasks
- WebSocket support cho real-time updates
- Task templates và workflows
