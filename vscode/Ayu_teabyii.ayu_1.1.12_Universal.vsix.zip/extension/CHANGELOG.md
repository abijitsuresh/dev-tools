If you run into any issues, please report them at <https://github.com/ayu-theme/vscode-ayu/issues>

## 1.1.12

`2026-04-09`

- Add icon for claude.md file

## 1.1.9

`2026-02-13`

- More prominent styling of custom menus

## 1.1.8

`2026-02-07`

- Fix the hover/active background of action buttons in action bar and toolbar

## 1.1.7

`2026-01-03`

- Fix the background of the chat confirmation requests

## 1.1.5

`2025-12-24`

- Support semantic highlighting, especially for languages like Rust
- Colors in chat interfaces (slash commands, bubbles, etc.)
- Proper shadows/dividers for sticky scrolls
- Make popup panels (Find/Replace, Command Prompt, etc) prominent
- Several new icons in the Ayu icon theme and refinements to existing SVG ones
- More color balancing in the Dark theme's UI
- Increased contrast in the Explorer for git entries (markers for added/modified/removed files/directories)
- Marginally increase contrast of the syntax in the Light theme, specifically functions and decorators
- Increase regular text's contrast in the editor in Light theme
- Add missing colors for non-default activity bar positions (top or bottom)

## 1.0.2

`2021-07-4`

- Fixed bracket match

## 1.0.1

`2021-07-3`

- Fixed secndary buttons

## 1.0.0

`2021-07-2`

- Semantic highlighting
- Improved color contrast
- Revised dark theme
- Updated/added file icons
- Revised UI colors

## 0.20.0

`2020-06-16`

- Fix for [Issue 101](https://github.com/ayu-theme/vscode-ayu/issues/101)

## 0.20.0

`2020-06-16`

- Add webpack, rollup, c header and graphql icons, more details: [PR](https://github.com/ayu-theme/vscode-ayu/pull/100)
- Contrast improvements:
  - Dark theme got more prominent UI colors
  - Light theme got darker foreground color
  - Errors in explorer have highlight color matching the themes
  - Search in explorer is fixed
  - Ident guides in light theme got a bit fainter
  - Ident guides in the explorer match those in the editor
  - Active tab in bordered version lost bottom border
  - Hover/Selection in status bar matches the themes
  - Sidebar group titles got borders
  - Icons throughout the editor have consistent colors
  - Some other tweaks I can't recall...

## 0.19.0

`2020-06-11`

- Fix selection and word highlight, more details: [PR](https://github.com/ayu-theme/vscode-ayu/pull/98)
- Fix jest icon
- Add Reasonml & Elm & C# icon

## 0.18.0

`2019-02-04`

- Fix unreadable ansi brightWhite in light terminal theme
- Adds jest & dart icon

## 0.17.0

`2018-11-14`

- Add bordered versions of all 3 themes with improved focus on editing;
- Fix Java, Python, Haskell and Go highlighting issues;
- Improve contrast in Dark theme;
- Balance Light theme's colours for better balance both on P3 and sRGB displays;
- Unify terminal colours

**(All by [dempfi](https://github.com/dempfi)'s [PR](https://github.com/teabyii/vscode-ayu/pull/70))**

## 0.16.0

`2018-08-30`

- Fix functions' arguments colours (thanks to [dempfi](https://github.com/dempfi))

## 0.15.0

`2018-08-17`

- Thanks to [dempfi](https://github.com/dempfi)'s [PR](https://github.com/teabyii/vscode-ayu/pull/60) for the changes in this release
- Use ayu colors from delicated package
- Update color schemes to match those of recent versions in sublime theme
- Update UI colors to reduce contrast, and improve focus on editor

## 0.14.0

`2018-03-09`

- Updated missing ayu icons

## 0.13.0

`2018-03-03`

- Improve Elixir and Ruby highlighting for modules
- Update icons to match new ayu icons

## 0.12.0

`2018-01-11`

- Add JSDoc instance support

## 0.11.2

`2018-01-04`

- Fix syntax on functions with "support.function" scope

## 0.11.1

`2017-12-22`

- Fix issue with error colors to scrollbar

## 0.11.0

`2017-12-22`

- Adding warning and error colors to scrollbar
- Colors for markdown inline and block code
- Add accent color to active tab border

## 0.10.0

`2017-11-13`

- Use correct colors for JSX tags

## 0.9.0

`2017-11-13`

- Hide explorer arrows in file icon theme

## 0.8.0

`2017-09-21`

- Show border on activity bar

## 0.7.0

`2017-09-19`

- Thanks to [dempfi](https://github.com/dempfi) for the changes in this release
- Updated logo that is shown in vs market
- Changed background for active tab
- Added border to titlebar and statusbar
- Other small improvements for inputs and such

## 0.6.0

`2017-08-24`

- Use border for active input option

## 0.5.0

`2017-08-11`

- Improved text contrast in dark and mirage themes

## 0.4.0

`2017-06-21`

- Theming for the VSCode 1.13 release
- Added theming of welcome page and interactive playground
- Fixed:
  - [Tree selection inactive color not visible](https://github.com/teabyii/vscode-ayu/issues/12)
  - [Change status bar highlight](https://github.com/teabyii/vscode-ayu/issues/13)
  - [Use correct colors for input validation](https://github.com/teabyii/vscode-ayu/issues/14)
  - [Add border between file manager and editor](https://github.com/teabyii/vscode-ayu/issues/15)
  - [Change the color of warning/error squiggles](https://github.com/teabyii/vscode-ayu/issues/16)

## 0.3.0

`2017-05-18`

- Thanks for [@pahen](https://github.com/pahen)'s [PR](https://github.com/teabyii/vscode-ayu/pull/8) for theming of entire workbench
- Use `build.js` to generate the 3 themes from the colors schemes defined in [ayu-colors](https://github.com/ayu-theme/ayu-colors)
- Use `npm run package` to build VSIX package
- Fixed:
  - [VSCode ayu light selection + find highlight = bad contrast](https://github.com/teabyii/vscode-ayu/issues/3)
  - [wrong icon filename for coffeescript](https://github.com/teabyii/vscode-ayu/issues/6)

## 0.2.1

`2016-11-16`

Fixed: [Whitespace color is not right](https://github.com/jsenjoy/vscode-ayu/issues/2)

## 0.2.0

`2016-11-08`

Update from ayu@2.0.0, add Mirage theme

## 0.1.0

`2016-10-14`

First version which forks ayu@1.3.2
